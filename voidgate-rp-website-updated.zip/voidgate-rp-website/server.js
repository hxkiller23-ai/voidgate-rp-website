require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const helmet = require("helmet");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

if (isProduction && !process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET must be set in production.");
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "voidgate.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'player',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS recruitment_applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    faction TEXT NOT NULL,
    experience TEXT NOT NULL,
    motivation TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS event_rsvps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, event_id)
  );
`);

const factions = [
  { id: "police", name: "Police Department", short: "PD", category: "STATE", description: "Protect citizens, respond to calls, and keep the city safe.", requirements: "Professional roleplay, teamwork, and knowledge of server rules." },
  { id: "fbi", name: "Federal Bureau of Investigation", short: "FBI", category: "STATE", description: "Investigate major cases and coordinate high-risk operations.", requirements: "Strong communication, patience, and clean roleplay history." },
  { id: "army", name: "Military", short: "ARMY", category: "STATE", description: "Support city security through disciplined operations and training.", requirements: "Discipline, activity, and teamwork." },
  { id: "mechanic", name: "Mechanic Workshop", short: "MECH", category: "CIVILIAN", description: "Keep the city moving with repairs, service, and business roleplay.", requirements: "Helpful attitude and consistent activity." },
  { id: "underground", name: "Underground Crew", short: "OCG", category: "UNDERGROUND", description: "Build a crew reputation through story-driven roleplay.", requirements: "Respect server rules and keep roleplay fair." }
];

const events = [
  { id: 1, title: "Midnight Street Meet", category: "COMMUNITY", date: "2026-10-24T19:00:00+05:30", location: "Downtown Plaza", description: "Bring your ride, meet other citizens, and take part in a clean car showcase.", reward: "Community rewards" },
  { id: 2, title: "Faction Showdown", category: "COMPETITION", date: "2026-10-27T20:00:00+05:30", location: "Training Grounds", description: "A coordinated team competition focused on teamwork and fair play.", reward: "In-game prize pool" },
  { id: 3, title: "Halloween Hunt", category: "SEASONAL", date: "2026-10-31T18:30:00+05:30", location: "City-wide", description: "Explore the city, find seasonal collectibles, and claim event rewards.", reward: "Seasonal rewards" }
];

const properties = [
  { id: 1, type: "HOUSE", name: "Vinewood Hills Residence", price: "$850,000", details: "Hillside home · Garage · Scenic view", status: "SHOWCASE" },
  { id: 2, type: "HOUSE", name: "Downtown Apartment", price: "$320,000", details: "City access · Compact · Modern interior", status: "SHOWCASE" },
  { id: 3, type: "BUSINESS", name: "Midnight Customs", price: "$1,250,000", details: "Vehicle workshop · Roleplay business concept", status: "SHOWCASE" },
  { id: 4, type: "BUSINESS", name: "Neon Corner Café", price: "$640,000", details: "Food & beverage · Community hotspot", status: "SHOWCASE" }
];

function safeUser(user) {
  if (!user) return null;
  return { id: user.id, username: user.username, email: user.email, role: user.role, created_at: user.created_at };
}

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in to continue." });
  next();
}

function requireAdmin(req, res, next) {
  const user = db.prepare("SELECT id, role FROM users WHERE id = ?").get(req.session.userId);
  if (!user || user.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  next();
}

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  name: "vg.sid",
  secret: process.env.SESSION_SECRET || "local-development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));
app.use(express.static(path.join(__dirname, "public")));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

app.get("/api/health", (req, res) => res.json({ status: "ok", name: "VoidGate RP API" }));
app.get("/api/public-config", (req, res) => res.json({ discordInvite: process.env.DISCORD_INVITE || "" }));

app.get("/api/me", (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = db.prepare("SELECT id, username, email, role, created_at FROM users WHERE id = ?").get(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.json({ user: null });
  }
  res.json({ user: safeUser(user) });
});

app.post("/api/register", authLimiter, (req, res) => {
  const username = String(req.body.username || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: "Username must be 3–20 characters and use letters, numbers or underscores." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 160) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 10 || password.length > 72) return res.status(400).json({ error: "Password must be 10–72 characters." });
  const hash = bcrypt.hashSync(password, 12);
  try {
    const result = db.prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)").run(username, email, hash);
    req.session.userId = result.lastInsertRowid;
    const user = db.prepare("SELECT id, username, email, role, created_at FROM users WHERE id = ?").get(result.lastInsertRowid);
    res.status(201).json({ user: safeUser(user) });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) return res.status(409).json({ error: "That username or email is already registered." });
    console.error(err);
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/login", authLimiter, (req, res) => {
  const identifier = String(req.body.identifier || "").trim();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE").get(identifier, identifier);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: "Incorrect username/email or password." });
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: "Could not start a session." });
    req.session.userId = user.id;
    res.json({ user: safeUser(user) });
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("vg.sid");
    res.json({ ok: true });
  });
});

app.get("/api/factions", (req, res) => res.json({ factions }));
app.get("/api/events", (req, res) => res.json({ events }));
app.get("/api/properties", (req, res) => res.json({ properties }));

app.post("/api/events/:id/rsvp", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!events.some(event => event.id === id)) return res.status(404).json({ error: "Event not found." });
  try {
    db.prepare("INSERT INTO event_rsvps (user_id, event_id) VALUES (?, ?)").run(req.session.userId, id);
    res.status(201).json({ ok: true, message: "You're on the event list." });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) return res.status(409).json({ error: "You have already joined this event." });
    console.error(err);
    res.status(500).json({ error: "Could not join event." });
  }
});

app.post("/api/recruitment", requireAuth, (req, res) => {
  const faction = String(req.body.faction || "").trim();
  const experience = String(req.body.experience || "").trim();
  const motivation = String(req.body.motivation || "").trim();
  if (!factions.some(item => item.name === faction)) return res.status(400).json({ error: "Choose a valid faction." });
  if (experience.length > 2000 || motivation.length < 20 || motivation.length > 2000) return res.status(400).json({ error: "Motivation must be 20–2000 characters; experience must be under 2000." });
  const existing = db.prepare("SELECT id FROM recruitment_applications WHERE user_id = ? AND faction = ? AND status = 'pending'").get(req.session.userId, faction);
  if (existing) return res.status(409).json({ error: "You already have a pending application for this faction." });
  const result = db.prepare("INSERT INTO recruitment_applications (user_id, faction, experience, motivation) VALUES (?, ?, ?, ?)").run(req.session.userId, faction, experience, motivation);
  res.status(201).json({ ok: true, id: result.lastInsertRowid, message: "Application submitted for staff review." });
});

app.get("/api/admin/applications", requireAuth, requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT a.id, a.faction, a.experience, a.motivation, a.status, a.created_at, u.username, u.email
    FROM recruitment_applications a JOIN users u ON u.id = a.user_id
    ORDER BY a.created_at DESC LIMIT 200
  `).all();
  res.json({ applications: rows });
});

app.patch("/api/admin/applications/:id", requireAuth, requireAdmin, (req, res) => {
  const status = String(req.body.status || "");
  if (!["pending", "accepted", "rejected"].includes(status)) return res.status(400).json({ error: "Status must be pending, accepted or rejected." });
  const result = db.prepare("UPDATE recruitment_applications SET status = ? WHERE id = ?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Application not found." });
  res.json({ ok: true });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => {
  console.log(`VoidGate RP website running at http://localhost:${PORT}`);
});
