const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
let currentUser = null;
let authMode = "login";
const modal = $("#auth-modal");
const toast = $("#toast");

$("#year").textContent = new Date().getFullYear();

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 3400);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
function openAuth(mode = "login") {
  setAuthMode(mode);
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  setTimeout(() => $("[name='identifier']").focus(), 60);
}
function closeAuth() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
function setAuthMode(mode) {
  authMode = mode;
  $$(".auth-tabs button").forEach(button => button.classList.toggle("active", button.dataset.authTab === mode));
  $("#username-label").classList.toggle("hidden", mode !== "register");
  $("#email-label").classList.toggle("hidden", mode !== "register");
  $("#identifier-label").classList.toggle("hidden", mode !== "login");
  $("[name='username']").required = mode === "register";
  $("[name='email']").required = mode === "register";
  $("[name='identifier']").required = mode === "login";
  $("[name='password']").autocomplete = mode === "register" ? "new-password" : "current-password";
  $("#auth-title").innerHTML = mode === "register" ? "CLAIM YOUR <em>PLACE.</em>" : "WELCOME <em>TO THE CITY.</em>";
  $("#auth-submit").textContent = mode === "register" ? "CREATE ACCOUNT ↗" : "LOG IN ↗";
  $("#auth-message").textContent = "";
}
function updateAccountUI() {
  const old = $("#account-nav");
  if (old) old.remove();
  const nav = $("#main-nav");
  if (currentUser) {
    const account = document.createElement("button");
    account.id = "account-nav";
    account.className = "button button-outline button-small";
    account.textContent = currentUser.username.toUpperCase();
    account.addEventListener("click", () => {
      if (confirm(`Logged in as ${currentUser.username}. Log out?`)) logout();
    });
    nav.insertBefore(account, nav.lastElementChild);
    $$(".site-header nav [data-open-auth]").forEach(el => { if (el.textContent.includes("LOG IN")) el.classList.add("hidden"); });
  } else {
    $$(".site-header nav [data-open-auth]").forEach(el => el.classList.remove("hidden"));
  }
}
async function loadMe() {
  try {
    const data = await api("/api/me");
    currentUser = data.user;
    updateAccountUI();
  } catch { currentUser = null; }
}
async function logout() {
  try {
    await api("/api/logout", { method: "POST", body: "{}" });
    currentUser = null;
    updateAccountUI();
    showToast("You have logged out.");
  } catch (error) { showToast(error.message); }
}
$("#auth-form").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const password = form.get("password");
  const body = authMode === "register"
    ? { username: form.get("username"), email: form.get("email"), password }
    : { identifier: form.get("identifier"), password };
  const submit = $("#auth-submit");
  submit.disabled = true;
  submit.textContent = "PLEASE WAIT…";
  $("#auth-message").textContent = "";
  try {
    const data = await api(authMode === "register" ? "/api/register" : "/api/login", { method: "POST", body: JSON.stringify(body) });
    currentUser = data.user;
    updateAccountUI();
    closeAuth();
    event.currentTarget.reset();
    showToast(`Welcome to the city, ${currentUser.username}.`);
  } catch (error) {
    $("#auth-message").textContent = error.message;
  } finally {
    submit.disabled = false;
    submit.textContent = authMode === "register" ? "CREATE ACCOUNT ↗" : "LOG IN ↗";
  }
});
$$("[data-open-auth]").forEach(button => button.addEventListener("click", () => openAuth(button.dataset.openAuth)));
$$("[data-close-modal]").forEach(button => button.addEventListener("click", closeAuth));
$$("[data-auth-tab]").forEach(button => button.addEventListener("click", () => setAuthMode(button.dataset.authTab)));
document.addEventListener("keydown", event => { if (event.key === "Escape") closeAuth(); });
$("#menu-toggle").addEventListener("click", () => {
  const nav = $("#main-nav");
  const open = nav.classList.toggle("open");
  $("#menu-toggle").setAttribute("aria-expanded", String(open));
});
$$('#main-nav a').forEach(link => link.addEventListener("click", () => $("#main-nav").classList.remove("open")));

function factionMarkup(faction) {
  return `<article class="faction-card"><div class="faction-top"><div class="faction-icon">${escapeHTML(faction.short)}</div><span class="pill">${escapeHTML(faction.category)}</span></div><h3>${escapeHTML(faction.name)}</h3><p>${escapeHTML(faction.description)}</p><button class="text-link" data-apply-faction="${escapeHTML(faction.name)}">VIEW REQUIREMENTS ↗</button></article>`;
}
async function loadFactions() {
  try {
    const { factions } = await api("/api/factions");
    $("#faction-list").innerHTML = factions.map(factionMarkup).join("");
    $$("[data-apply-faction]").forEach(button => button.addEventListener("click", () => {
      if (!currentUser) return openAuth("login");
      showToast(`${button.dataset.applyFaction}: ${factions.find(f => f.name === button.dataset.applyFaction)?.requirements || ""}`);
      const motivation = prompt("Why do you want to join this faction? (At least 20 characters)");
      if (motivation === null) return;
      const experience = prompt("Describe your roleplay experience (optional).") || "";
      api("/api/recruitment", { method: "POST", body: JSON.stringify({ faction: button.dataset.applyFaction, motivation, experience }) })
        .then(result => showToast(result.message)).catch(error => showToast(error.message));
    }));
  } catch { $("#faction-list").innerHTML = '<div class="empty">Factions are temporarily unavailable.</div>'; }
}
function eventDate(date) {
  const d = new Date(date);
  return { day: d.toLocaleDateString("en-US", { day: "2-digit" }), month: d.toLocaleDateString("en-US", { month: "short" }).toUpperCase(), time: d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }) };
}
async function loadEvents() {
  try {
    const { events } = await api("/api/events");
    $("#event-list").innerHTML = events.map(event => {
      const date = eventDate(event.date);
      return `<article class="event-row"><div class="event-date"><b>${date.day}</b><span>${date.month}</span></div><div class="event-info"><span class="pill">${escapeHTML(event.category)}</span><h3>${escapeHTML(event.title)}</h3><p>${escapeHTML(event.description)}</p></div><div class="event-location"><span>LOCATION / ${date.time}</span>${escapeHTML(event.location)}</div><button class="button button-outline" data-rsvp="${event.id}">JOIN EVENT ↗</button></article>`;
    }).join("");
    $$("[data-rsvp]").forEach(button => button.addEventListener("click", async () => {
      if (!currentUser) return openAuth("login");
      button.disabled = true;
      try { const result = await api(`/api/events/${button.dataset.rsvp}/rsvp`, { method: "POST", body: "{}" }); showToast(result.message); }
      catch (error) { showToast(error.message); }
      finally { button.disabled = false; }
    }));
  } catch { $("#event-list").innerHTML = '<div class="empty">Events are temporarily unavailable.</div>'; }
}
async function loadProperties() {
  try {
    const { properties } = await api("/api/properties");
    $("#property-list").innerHTML = properties.map(property => `<article class="property-card"><div class="property-art ${property.type === "HOUSE" ? "house" : "business"}"><span class="pill">${escapeHTML(property.type)}</span><span class="property-symbol">${property.type === "HOUSE" ? "⌂" : "▧"}</span></div><div class="property-body"><h3>${escapeHTML(property.name)}</h3><p>${escapeHTML(property.details)}</p><div class="property-price"><b>${escapeHTML(property.price)}</b><span>${escapeHTML(property.status)}</span></div></div></article>`).join("");
  } catch { $("#property-list").innerHTML = '<div class="empty">Property listings are temporarily unavailable.</div>'; }
}
async function loadConfig() {
  // Discord invite can be set in the backend environment; this endpoint intentionally exposes only public configuration.
  try {
    const response = await fetch("/api/public-config");
    if (!response.ok) return;
    const config = await response.json();
    if (config.discordInvite) {
      $("#discord-link").href = config.discordInvite;
      $("#footer-discord").href = config.discordInvite;
    }
  } catch {}
}
Promise.all([loadMe(), loadFactions(), loadEvents(), loadProperties(), loadConfig()]);
