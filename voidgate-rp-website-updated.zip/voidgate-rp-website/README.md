# VoidGate RP website starter

A responsive GTA-inspired community website for **VoidGate RP**, with a Node.js/Express backend and SQLite database.

## Included
- Responsive home page with cinematic placeholder artwork
- Registration, login, logout and session-based authentication
- Password hashing with bcrypt
- Faction/recruitment page and application submission
- Events page and event RSVP
- Houses and businesses directory (demo listings)
- Profile/dashboard page
- Basic admin endpoints for reviewing recruitment applications
- Helmet security headers and rate limiting on authentication endpoints

## Requirements
- Node.js 20+
- npm

## Run locally
1. Extract the ZIP.
2. Copy `.env.example` to `.env`.
3. Replace `SESSION_SECRET` with a long random value.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

SQLite data is created automatically in `data/voidgate.sqlite`.

## Important before production
This is a functional starter, not a production-ready game account integration. The login accounts belong to this website and are **not** automatically connected to your game server. To connect in-game player data, you will need a trusted server API or database integration.

Before public launch:
- Use HTTPS and set `NODE_ENV=production`.
- Configure secure cookies and a strong `SESSION_SECRET`.
- Add email verification and password reset.
- Add CSRF protection and a persistent session store.
- Create an admin account through a controlled admin-seeding process; do not make public registration grant admin rights.
- Replace demo houses, businesses and events with verified data.
- Add moderation, privacy policy, terms and backups.
- Never expose game-server credentials or database passwords in frontend JavaScript.

## Admin endpoints
Admin endpoints require a user whose database `role` is `admin`. New registrations are always `player`. For local development, you can promote your own account by opening the SQLite database with a trusted SQLite tool and running:

```sql
UPDATE users SET role = 'admin' WHERE username = 'your_username';
```

Do not expose database access to the public. The admin API currently supports viewing and updating recruitment application status.

## API overview
- `GET /api/me`
- `POST /api/register`
- `POST /api/login`
- `POST /api/logout`
- `GET /api/factions`
- `GET /api/events`
- `POST /api/events/:id/rsvp` (login required)
- `GET /api/properties`
- `POST /api/recruitment` (login required)
- `GET /api/admin/applications` (admin required)
- `PATCH /api/admin/applications/:id` (admin required)

All listings are seeded demo content. Update the seed data in `server.js` for your actual server.


## Public community links

- Discord: https://discord.gg/yergYgbEg
- Game APK download (MediaFire, v2.0): https://www.mediafire.com/file/hmhxsc81azu3bv1/VoidGate_Roleplay_Latest_%28v.2.0%29.apk/file

The website links to the APK host; it does not host or verify the APK file itself.
