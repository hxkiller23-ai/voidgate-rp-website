@echo off
title VoidGate RP Website
echo =====================================
echo       VOIDGATE RP WEBSITE
echo =====================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js 20 or newer from https://nodejs.org/
  pause
  exit /b 1
)
if not exist .env (
  copy .env.example .env >nul
  echo Created .env. For production, change SESSION_SECRET before publishing.
)
echo Installing required packages...
call npm install
if errorlevel 1 (
  echo Dependency installation failed. Check your Node.js version and internet connection.
  pause
  exit /b 1
)
echo Starting VoidGate RP...
call npm start
pause
